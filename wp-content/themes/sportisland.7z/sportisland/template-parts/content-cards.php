<section class="cards cards_index">
    <div class="wrapper">
        <h2 class="main-heading cards__h"> клубные карты </h2>
        <ul class="cards__list row">
            <li class="card">
                <h3 class="card__name"> полный день </h3>
                <p class="card__time"> 7:00 &ndash; 22:00 </p>
                <p class="card__price price"> 3200 <span class="price__unit" aria-label="рублей в месяц">р.-/мес.</span>
                </p>
                <ul class="card__features">
                    <li class="card__feature">Безлимит посещений клуба</li>
                    <li class="card__feature">Вводный инструктаж</li>
                    <li class="card__feature">Групповые занятия</li>
                    <li class="card__feature">Сауна</li>
                </ul>
                <a data-post-id="99" href="#modal-form" class="card__buy btn btn_modal">купить</a>
            </li>
            <li class="card card_profitable">
                <h3 class="card__name"> полный день </h3>
                <p class="card__time"> 7:00 &ndash; 22:00 </p>
                <p class="card__price price"> 3200 <span class="price__unit" aria-label="рублей в месяц">р.-/мес.</span>
                </p>
                <ul class="card__features">
                    <li class="card__feature">Безлимит посещений клуба</li>
                    <li class="card__feature">Вводный инструктаж</li>
                    <li class="card__feature">Групповые занятия</li>
                    <li class="card__feature">Сауна</li>
                </ul>
                <a data-post-id="99" href="#modal-form" class="card__buy btn btn_modal">купить</a>
            </li>
            <li class="card">
                <h3 class="card__name"> полный день </h3>
                <p class="card__time"> 7:00 &ndash; 22:00 </p>
                <p class="card__price price"> 3200 <span class="price__unit" aria-label="рублей в месяц">р.-/мес.</span>
                </p>
                <ul class="card__features">
                    <li class="card__feature">Безлимит посещений клуба</li>
                    <li class="card__feature">Вводный инструктаж</li>
                    <li class="card__feature">Групповые занятия</li>
                    <li class="card__feature">Сауна</li>
                </ul>
                <a data-post-id="99" href="#modal-form" class="card__buy btn btn_modal">купить</a>
            </li>
            <li class="card">
                <h3 class="card__name"> полный день </h3>
                <p class="card__time"> 7:00 &ndash; 22:00 </p>
                <p class="card__price price"> 3200 <span class="price__unit" aria-label="рублей в месяц">р.-/мес.</span>
                </p>
                <ul class="card__features">
                    <li class="card__feature">Безлимит посещений клуба</li>
                    <li class="card__feature">Вводный инструктаж</li>
                    <li class="card__feature">Групповые занятия</li>
                    <li class="card__feature">Сауна</li>
                </ul>
                <a data-post-id="99" href="#modal-form" class="card__buy btn btn_modal">купить</a>
            </li>
        </ul>
    </div>
</section>
