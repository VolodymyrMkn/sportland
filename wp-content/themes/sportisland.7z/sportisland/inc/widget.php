<?php
add_action('widgets_init', 'my_vitos_widgets_init');

function my_vitos_widgets_init(){

    register_sidebar(array(
        'name' => 'Виджет ввывода текста',
        'id' => 'category_text',
        'description' => 'Вывод текста',
        'before_widget' => '<p class="widget-contacts__address">', // next level
        'after_widget' => '</p>',
    ));

}
?>
